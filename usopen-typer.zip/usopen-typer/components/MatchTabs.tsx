'use client';

import { useState } from 'react';
import MatchCard from './MatchCard';

export default function MatchTabs({
  upcoming,
  live,
  finished,
  predictionsByMatchId,
  isLoggedIn,
}: {
  upcoming: any[];
  live: any[];
  finished: any[];
  predictionsByMatchId: Record<string, any>;
  isLoggedIn: boolean;
}) {
  const [tab, setTab] = useState<'live' | 'upcoming' | 'finished'>(
    live.length > 0 ? 'live' : 'upcoming'
  );

  const tabs: { key: typeof tab; label: string; data: any[] }[] = [
    { key: 'live', label: `Live (${live.length})`, data: live },
    { key: 'upcoming', label: `Nierozpoczęte (${upcoming.length})`, data: upcoming },
    { key: 'finished', label: `Zakończone (${finished.length})`, data: finished },
  ];

  const active = tabs.find((t) => t.key === tab)!;

  return (
    <div>
      <div className="mb-4 flex gap-1 rounded-lg bg-slate-200 p-1">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex-1 rounded-md py-2 text-sm font-medium transition ${
              tab === t.key ? 'bg-white shadow' : 'text-slate-600'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {active.data.length === 0 && (
          <p className="py-8 text-center text-slate-400">Brak meczów w tej kategorii.</p>
        )}
        {active.data.map((m) => (
          <MatchCard
            key={m.id}
            match={m}
            myPrediction={predictionsByMatchId[m.id] || null}
            isLoggedIn={isLoggedIn}
          />
        ))}
      </div>
    </div>
  );
}
