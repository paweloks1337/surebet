import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/requireAdmin';
import { supabaseAdmin } from '@/lib/supabaseAdmin';

export async function POST(request: Request) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: 'Brak dostępu.' }, { status: 403 });

  const { question, options, points, deadline } = await request.json();
  if (!question || !deadline) {
    return NextResponse.json({ error: 'Uzupełnij pytanie i deadline.' }, { status: 400 });
  }

  const { error } = await supabaseAdmin().from('bonus_questions').insert({
    question,
    options: options && options.length ? options : null,
    points: points || 5,
    deadline,
  });

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ ok: true });
}
