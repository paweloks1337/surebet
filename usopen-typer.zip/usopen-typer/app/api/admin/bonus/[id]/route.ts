import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/requireAdmin';
import { supabaseAdmin } from '@/lib/supabaseAdmin';

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: 'Brak dostępu.' }, { status: 403 });

  const body = await request.json();
  const db = supabaseAdmin();
  const questionId = params.id;

  const updates: Record<string, any> = { updated_at: new Date().toISOString() };
  if (body.question !== undefined) updates.question = body.question;
  if (body.deadline !== undefined) updates.deadline = body.deadline;
  if (body.points !== undefined) updates.points = body.points;

  const resolving = body.correct_answer !== undefined;
  if (resolving) {
    updates.correct_answer = body.correct_answer;
    updates.status = 'resolved';
  }

  const { error } = await db.from('bonus_questions').update(updates).eq('id', questionId);
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });

  if (resolving) {
    const { data: question } = await db
      .from('bonus_questions')
      .select('points, correct_answer')
      .eq('id', questionId)
      .single();

    const { data: answers } = await db
      .from('bonus_answers')
      .select('*')
      .eq('bonus_question_id', questionId);

    for (const a of answers || []) {
      const correct =
        a.answer.trim().toLowerCase() === (question?.correct_answer || '').trim().toLowerCase();
      await db
        .from('bonus_answers')
        .update({ points: correct ? question?.points || 0 : 0 })
        .eq('id', a.id);
    }
  }

  return NextResponse.json({ ok: true });
}

export async function DELETE(_request: Request, { params }: { params: { id: string } }) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: 'Brak dostępu.' }, { status: 403 });

  const { error } = await supabaseAdmin().from('bonus_questions').delete().eq('id', params.id);
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ ok: true });
}
