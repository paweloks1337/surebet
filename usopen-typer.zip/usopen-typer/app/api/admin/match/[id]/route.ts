import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/requireAdmin';
import { supabaseAdmin } from '@/lib/supabaseAdmin';
import { calculatePredictionPoints } from '@/lib/scoring';

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: 'Brak dostępu.' }, { status: 403 });

  const body = await request.json();
  const db = supabaseAdmin();
  const matchId = params.id;

  const updates: Record<string, any> = { updated_at: new Date().toISOString(), source: 'admin' };

  if (body.round !== undefined) updates.round = body.round;
  if (body.player1 !== undefined) updates.player1 = body.player1;
  if (body.player2 !== undefined) updates.player2 = body.player2;
  if (body.scheduled_at !== undefined) updates.scheduled_at = body.scheduled_at;
  if (body.deadline !== undefined) updates.deadline = body.deadline;
  if (body.status !== undefined) updates.status = body.status;

  // Admin ustawia/poprawia wynik ręcznie - to NADPISUJE to, co przyszło z API
  const settingResult =
    body.sets_p1 !== undefined && body.sets_p2 !== undefined && body.winner;

  if (settingResult) {
    updates.sets_p1 = body.sets_p1;
    updates.sets_p2 = body.sets_p2;
    updates.winner = body.winner;
    updates.status = 'finished';
    updates.needs_review = false; // admin potwierdził ręcznie -> koniec weryfikacji
  }

  const { error: updateError } = await db.from('matches').update(updates).eq('id', matchId);
  if (updateError) return NextResponse.json({ error: updateError.message }, { status: 400 });

  // Jeśli ustawiono/poprawiono wynik -> przelicz punkty wszystkich typów na ten mecz
  if (settingResult) {
    const { data: predictions } = await db
      .from('predictions')
      .select('*')
      .eq('match_id', matchId);

    for (const p of predictions || []) {
      const points = calculatePredictionPoints({
        predictedWinner: p.predicted_winner,
        predictedSetsP1: p.predicted_sets_p1,
        predictedSetsP2: p.predicted_sets_p2,
        actualWinner: body.winner,
        actualSetsP1: body.sets_p1,
        actualSetsP2: body.sets_p2,
      });
      await db.from('predictions').update({ points }).eq('id', p.id);
    }
  }

  return NextResponse.json({ ok: true });
}

export async function DELETE(_request: Request, { params }: { params: { id: string } }) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: 'Brak dostępu.' }, { status: 403 });

  const { error } = await supabaseAdmin().from('matches').delete().eq('id', params.id);
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ ok: true });
}
