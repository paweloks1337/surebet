import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/requireAdmin';
import { supabaseAdmin } from '@/lib/supabaseAdmin';

export async function POST(request: Request) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: 'Brak dostępu.' }, { status: 403 });

  const body = await request.json();
  const { round, player1, player2, scheduled_at, deadline } = body;

  if (!player1 || !player2 || !deadline) {
    return NextResponse.json({ error: 'Uzupełnij graczy i deadline.' }, { status: 400 });
  }

  const { error } = await supabaseAdmin().from('matches').insert({
    round,
    player1,
    player2,
    scheduled_at: scheduled_at || null,
    deadline,
    status: 'upcoming',
    source: 'admin',
  });

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ ok: true });
}
