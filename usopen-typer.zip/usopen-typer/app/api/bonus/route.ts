import { NextResponse } from 'next/server';
import { supabaseServer } from '@/lib/supabaseServer';

export async function POST(request: Request) {
  const supabase = supabaseServer();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: 'Musisz być zalogowany.' }, { status: 401 });
  }

  const { bonus_question_id, answer } = await request.json();
  if (!bonus_question_id || !answer) {
    return NextResponse.json({ error: 'Nieprawidłowe dane.' }, { status: 400 });
  }

  const { error } = await supabase.from('bonus_answers').upsert(
    {
      user_id: user.id,
      bonus_question_id,
      answer,
    },
    { onConflict: 'user_id,bonus_question_id' }
  );

  if (error) {
    return NextResponse.json(
      { error: 'Nie udało się zapisać odpowiedzi - może minął już deadline?' },
      { status: 400 }
    );
  }

  return NextResponse.json({ ok: true });
}
