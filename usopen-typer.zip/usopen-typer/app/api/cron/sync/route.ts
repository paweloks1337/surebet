import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabaseAdmin';
import { fetchLiveMatches, fetchUpcomingMatches, fetchMatchScore, parseSetsScore } from '@/lib/tennisApi';

// Ten endpoint wywołuje Vercel Cron (patrz vercel.json) albo GitHub Actions co kilka minut.
// Chroniony CRON_SECRET, żeby nikt z zewnątrz nie mógł go odpalać na żądanie (darmowy plan
// API ma limit 100 req/dzień - trzeba pilnować częstotliwości, np. co 10-15 min = ok. 96-144
// req/dzień na 2 zapytania listujące, więc raczej co 15 min żeby mieć zapas na fetchMatchScore).
export async function GET(request: Request) {
  const authHeader = request.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const db = supabaseAdmin();
  const log: string[] = [];

  try {
    const [live, upcoming] = await Promise.all([fetchLiveMatches(), fetchUpcomingMatches()]);
    const liveIds = new Set(live.map((m) => m.id));

    // 1) upsert live + upcoming mecze (tylko te, których admin ręcznie nie edytował - source='api')
    for (const m of [...live, ...upcoming]) {
      const { data: existing } = await db
        .from('matches')
        .select('id, source, deadline')
        .eq('external_id', m.id)
        .maybeSingle();

      if (existing && existing.source === 'admin') {
        log.push(`Pomijam ${m.id} - edytowany ręcznie przez admina`);
        continue;
      }

      const status = liveIds.has(m.id) ? 'live' : 'upcoming';
      const payload = {
        external_id: m.id,
        tournament: m.tournament || 'US Open 2026',
        round: m.round || null,
        player1: m.player1,
        player2: m.player2,
        player1_country: m.player1_country || null,
        player2_country: m.player2_country || null,
        scheduled_at: m.scheduled_at || null,
        status,
        source: 'api',
        last_synced_at: new Date().toISOString(),
      };

      if (existing) {
        await db.from('matches').update(payload).eq('id', existing.id);
      } else {
        // domyślny deadline = start meczu (jeśli brak - za godzinę); admin może to zmienić
        const deadline = m.scheduled_at || new Date(Date.now() + 60 * 60 * 1000).toISOString();
        await db.from('matches').insert({ ...payload, deadline });
      }
    }

    // 2) sety live -> zapisz aktualny wynik (przyda się jako "ostatni znany" gdy mecz zniknie z live)
    for (const m of live) {
      try {
        const score = await fetchMatchScore(m.id);
        const { setsP1, setsP2 } = parseSetsScore(score.sets);
        await db
          .from('matches')
          .update({ sets_p1: setsP1, sets_p2: setsP2, last_synced_at: new Date().toISOString() })
          .eq('external_id', m.id)
          .neq('source', 'admin');
      } catch (e: any) {
        log.push(`Błąd pobierania wyniku ${m.id}: ${e.message}`);
      }
    }

    // 3) mecze, które były 'live' w naszej bazie, a teraz zniknęły z listy live -> uznaj za zakończone
    // (darmowy plan nie ma historii zakończonych meczów, więc bazujemy na ostatnim znanym wyniku
    // i oznaczamy needs_review=true, żeby admin zerknął i ewentualnie poprawił)
    const { data: dbLive } = await db
      .from('matches')
      .select('*')
      .eq('status', 'live')
      .neq('source', 'admin');

    for (const m of dbLive || []) {
      if (m.external_id && !liveIds.has(m.external_id)) {
        const { setsP1, setsP2, winner } = parseSetsScore([m.sets_p1 ?? 0, m.sets_p2 ?? 0]);
        await db
          .from('matches')
          .update({
            status: 'finished',
            winner: winner,
            needs_review: true,
            updated_at: new Date().toISOString(),
          })
          .eq('id', m.id);

        if (winner) {
          const { data: predictions } = await db
            .from('predictions')
            .select('*')
            .eq('match_id', m.id);

          for (const p of predictions || []) {
            const { calculatePredictionPoints } = await import('@/lib/scoring');
            const points = calculatePredictionPoints({
              predictedWinner: p.predicted_winner,
              predictedSetsP1: p.predicted_sets_p1,
              predictedSetsP2: p.predicted_sets_p2,
              actualWinner: winner,
              actualSetsP1: setsP1,
              actualSetsP2: setsP2,
            });
            await db.from('predictions').update({ points }).eq('id', p.id);
          }
        }
        log.push(`Mecz ${m.player1} vs ${m.player2} oznaczony jako zakończony (do weryfikacji)`);
      }
    }

    return NextResponse.json({ ok: true, log });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message, log }, { status: 500 });
  }
}
