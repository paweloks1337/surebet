import { NextResponse } from 'next/server';
import { supabaseServer } from '@/lib/supabaseServer';

export async function POST(request: Request) {
  const supabase = supabaseServer();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: 'Musisz być zalogowany.' }, { status: 401 });
  }

  const body = await request.json();
  const { match_id, predicted_winner, predicted_sets_p1, predicted_sets_p2 } = body;

  if (!match_id || !['player1', 'player2'].includes(predicted_winner)) {
    return NextResponse.json({ error: 'Nieprawidłowe dane.' }, { status: 400 });
  }

  // upsert - RLS (patrz supabase/schema.sql) i tak zablokuje zapis po deadline / gdy mecz się zaczął
  const { error } = await supabase.from('predictions').upsert(
    {
      user_id: user.id,
      match_id,
      predicted_winner,
      predicted_sets_p1,
      predicted_sets_p2,
      updated_at: new Date().toISOString(),
    },
    { onConflict: 'user_id,match_id' }
  );

  if (error) {
    return NextResponse.json(
      { error: 'Nie udało się zapisać typu - może minął już deadline?' },
      { status: 400 }
    );
  }

  return NextResponse.json({ ok: true });
}
