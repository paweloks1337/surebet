import { supabaseServer } from '@/lib/supabaseServer';
import Image from 'next/image';

export const dynamic = 'force-dynamic';

export default async function AdminUsersPage() {
  const supabase = supabaseServer();
  const { data: ranking } = await supabase
    .from('ranking')
    .select('*')
    .order('total_points', { ascending: false });

  const { data: profiles } = await supabase.from('profiles').select('id, discord_id');
  const discordIdByUserId: Record<string, string> = {};
  (profiles || []).forEach((p) => (discordIdByUserId[p.id] = p.discord_id));

  return (
    <div>
      <h1 className="mb-3 text-xl font-bold">Użytkownicy</h1>
      <p className="mb-3 text-sm text-slate-500">
        Discord ID użytkownika wklej do zmiennej środowiskowej{' '}
        <code className="rounded bg-slate-100 px-1">ADMIN_DISCORD_IDS</code> na Vercelu, żeby nadać
        mu uprawnienia admina.
      </p>
      <div className="overflow-hidden rounded-xl border bg-white shadow-sm">
        <table className="w-full text-sm">
          <thead className="bg-slate-100 text-left text-slate-600">
            <tr>
              <th className="px-4 py-2">Gracz</th>
              <th className="px-4 py-2">Discord ID</th>
              <th className="px-4 py-2 text-right">Punkty</th>
            </tr>
          </thead>
          <tbody>
            {(ranking || []).map((r) => (
              <tr key={r.user_id} className="border-t">
                <td className="px-4 py-2">
                  <div className="flex items-center gap-2">
                    {r.avatar_url && (
                      <Image src={r.avatar_url} alt={r.username} width={24} height={24} className="rounded-full" />
                    )}
                    {r.username}
                  </div>
                </td>
                <td className="px-4 py-2 font-mono text-xs">{discordIdByUserId[r.user_id]}</td>
                <td className="px-4 py-2 text-right font-semibold">{r.total_points}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
