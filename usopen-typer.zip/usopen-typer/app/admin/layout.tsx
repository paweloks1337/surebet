import { redirect } from 'next/navigation';
import Link from 'next/link';
import { supabaseServer } from '@/lib/supabaseServer';
import { isAdminDiscordId } from '@/lib/isAdmin';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const supabase = supabaseServer();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect('/login');

  const { data: profile } = await supabase
    .from('profiles')
    .select('discord_id')
    .eq('id', user.id)
    .single();

  if (!isAdminDiscordId(profile?.discord_id)) {
    redirect('/matches');
  }

  return (
    <div>
      <div className="mb-4 flex gap-4 border-b pb-2 text-sm font-medium">
        <Link href="/admin" className="hover:text-usopen-blue">Mecze</Link>
        <Link href="/admin/bonus" className="hover:text-usopen-blue">Pytania bonusowe</Link>
        <Link href="/admin/users" className="hover:text-usopen-blue">Użytkownicy</Link>
      </div>
      {children}
    </div>
  );
}
