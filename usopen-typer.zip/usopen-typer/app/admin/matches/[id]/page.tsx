import { notFound } from 'next/navigation';
import { supabaseServer } from '@/lib/supabaseServer';
import EditMatchForm from '@/components/admin/EditMatchForm';

export const dynamic = 'force-dynamic';

export default async function EditMatchPage({ params }: { params: { id: string } }) {
  const supabase = supabaseServer();
  const { data: match } = await supabase.from('matches').select('*').eq('id', params.id).single();

  if (!match) notFound();

  return (
    <div>
      <h1 className="mb-3 text-xl font-bold">
        Edytuj: {match.player1} vs {match.player2}
      </h1>
      <EditMatchForm match={match} />
    </div>
  );
}
