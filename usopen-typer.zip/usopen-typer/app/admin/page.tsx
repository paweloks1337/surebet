import { supabaseServer } from '@/lib/supabaseServer';
import Link from 'next/link';
import AddMatchForm from '@/components/admin/AddMatchForm';

export const dynamic = 'force-dynamic';

export default async function AdminMatchesPage() {
  const supabase = supabaseServer();
  const { data: matches } = await supabase
    .from('matches')
    .select('*')
    .order('scheduled_at', { ascending: true });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="mb-3 text-xl font-bold">Dodaj mecz ręcznie</h1>
        <AddMatchForm />
      </div>

      <div>
        <h1 className="mb-3 text-xl font-bold">Wszystkie mecze</h1>
        <div className="space-y-2">
          {(matches || []).map((m) => (
            <Link
              key={m.id}
              href={`/admin/matches/${m.id}`}
              className="flex items-center justify-between rounded-lg border bg-white p-3 text-sm hover:bg-slate-50"
            >
              <span>
                <strong>{m.player1}</strong> vs <strong>{m.player2}</strong>{' '}
                <span className="text-slate-400">({m.round})</span>
              </span>
              <span className="flex items-center gap-2">
                {m.needs_review && (
                  <span className="rounded bg-amber-100 px-2 py-0.5 text-amber-700">
                    do weryfikacji
                  </span>
                )}
                <span className="rounded bg-slate-100 px-2 py-0.5">{m.status}</span>
                <span className="rounded bg-slate-100 px-2 py-0.5">{m.source}</span>
              </span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
