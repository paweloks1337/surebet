import { supabaseServer } from '@/lib/supabaseServer';
import AddBonusForm from '@/components/admin/AddBonusForm';
import BonusAdminCard from '@/components/admin/BonusAdminCard';

export const dynamic = 'force-dynamic';

export default async function AdminBonusPage() {
  const supabase = supabaseServer();
  const { data: questions } = await supabase
    .from('bonus_questions')
    .select('*')
    .order('created_at', { ascending: false });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="mb-3 text-xl font-bold">Dodaj pytanie bonusowe</h1>
        <AddBonusForm />
      </div>
      <div className="space-y-3">
        <h1 className="text-xl font-bold">Wszystkie pytania</h1>
        {(questions || []).map((q) => (
          <BonusAdminCard key={q.id} question={q} />
        ))}
      </div>
    </div>
  );
}
